import React from 'react'

export default () => {
  
  return (
    <div>
      footer.
    </div>
  )
}
